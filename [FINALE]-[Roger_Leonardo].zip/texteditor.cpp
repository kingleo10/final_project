#include<stdio.h>
#include<process.h>

    int choice;
    char fn[100],c;
    FILE *FA,*FB,*FP;

    void Create(){
        FA=fopen("file.txt","w");
        printf("\nEnter the text and press '.' to save\n\n\t");
        while(1){
            c=getchar();
            fputc(c,FA);
            
            if(c == '.'){
                fclose(FA);
                printf("\nEnter the new filename: ");
                scanf("%s",fn);
                FA=fopen("file.txt","r");
                FB=fopen(fn,"w");
                
                while(!feof(FA)){
                    c=getc(FA);
                    putc(c,FB);
					}
					fclose(FB);
					break;
			}
        }
    }
	
	void Display(){
		printf("\nEnter the file name: ");
		scanf("%s",fn);
		FA=fopen(fn,"r");
		
		if(FA==NULL){
		printf("\nFile not found");
		goto end1;
		}
		
		while(!feof(FA)){
		c=getc(FA);
		printf("%c",c);
		}
		end1:
		
		fclose(FA);
		printf("\nPress any key to continue");
		getchar();
		}
		
		void Delete(){
		printf("\nEnter the file name: ");
		scanf("%s",fn);
		FA=fopen(fn,"r");
		
		if(FA==NULL){
		printf("\nFile not found!");
		goto end2;
		}
		
		fclose(FA);
		if(remove(fn)==0){
		printf("\nFile deleted");
		goto end2;
		}
		else printf("\nError...\n");
		
		end2: printf("\nPress any key to continue");
		getchar();
		}
		
		void Append(){
		printf("\nEnter the file name:");
		scanf("%s",fn);
		FA=fopen(fn,"r");
		
		if(FA==NULL){
		printf("\nFile not found");
		goto end3;
		}
		
		while(!feof(FA)){
		c=getc(FA);
		printf("%c",c);
		}
		
		fclose(FA);
		printf("\t\nType the text and press 'Ctrl+S' to append\n");
		FA=fopen(fn,"a");
		while(1){
		c=getchar();
		
		if(c==19) goto end3;
		
		else if(c==13){
		c='\n';
		printf("\n\t");
		fputc(c,FA);
		}
		
		else{
		printf("%c",c);
		fputc(c,FA);
		}
	}
	end3: fclose(FA);
	getchar();
}

    int main(){
	void Create();
	void Append();
	void Delete();
	void Display();

    do{
	printf("Text Editor\n");
	printf("Choices:\n");
	printf("1.Create file\n");
	printf("2.Display file\n");
	printf("3.Append\n");
	printf("4.Delete\n");
	printf("5.Exit\n");
	printf("Enter choice:");
	scanf("%d",&choice);
	    
		switch(choice){
		case 1:
		Create();
		break;
		case 2:
		Display();
		break;
		case 3:
		Append();
		break;
		case 4:
		Delete();
		break;
		case 5:
		exit(0);
		}
	}while(1);
 return 0;
}
